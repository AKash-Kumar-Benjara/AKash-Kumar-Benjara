package com.frs.src;

public class Contact {
    String name, phone, email;

    public String getContactDetails() {
        return name+" "+phone+" "+email;
    }
    public void updateContactDetails(String contactDetails) {
        contactDetails = contactDetails;
        return ;
    }
}
