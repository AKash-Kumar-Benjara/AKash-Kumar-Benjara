package com.frs.src;

public class Address {
    String street, city, state;
    Address(String street, String city, String state) {
        this.street = street;
        this.city = city;
        this.state = state;
    }

}
